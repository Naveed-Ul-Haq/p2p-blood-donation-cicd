console.log("Backend placeholder running");
