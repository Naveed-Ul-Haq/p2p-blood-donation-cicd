# Backend Service

This folder will contain the Node.js (Express) backend
for the Real-Time Blood Donation System.

Planned features:
- Authentication
- Donor/Recipient APIs
- Real-time request handling
