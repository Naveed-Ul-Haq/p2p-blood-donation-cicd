# Mobile Application

This folder will contain the React Native mobile application
for donors, recipients, and admin users.

Planned features:
- User authentication
- Donor availability toggle
- Live location tracking
